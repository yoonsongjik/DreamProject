package com.example.vip;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Setting extends AppCompatActivity {
    TextView User_Name_View, User_Id_View, User_Pw_View, User_Email_View, User_Hard_Name_View, User_Hard_Number_View;
    RadioButton Alarm_On, Alarm_Off;
    TextView Delete_Hard, Delete_User, LogOut, Pw_Change;
    String User_Name, Id, Pw, Email, Device_Name, Device_Code, Alarm_Status, user_id;
    ImageButton Setting_Back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        User_Name_View = findViewById(R.id.user_name_view);
        User_Id_View = findViewById(R.id.user_id_view);
        User_Pw_View = findViewById(R.id.user_pw_view);
        User_Email_View = findViewById(R.id.user_email_view);
        User_Hard_Name_View = findViewById(R.id.user_hard_name_view);
        User_Hard_Number_View = findViewById(R.id.user_hard_number_view);
        Alarm_On = findViewById(R.id.alarm_on);
        Alarm_Off = findViewById(R.id.alarm_off);
        Pw_Change = findViewById(R.id.pw_change);
        Delete_Hard = findViewById(R.id.delete_hard);
        Delete_User = findViewById(R.id.delete_user);
        LogOut = findViewById(R.id.logout);
        Setting_Back = findViewById(R.id.Setting_back);

        //뒤로 가기 버튼
        Setting_Back.setOnClickListener(v -> onBackPressed() );

        IdSave idSave = (IdSave) getApplication();
        int isAutoLogin = idSave.getIsAutoLogin();

        if(isAutoLogin == 1)
        {
            // 사용자의 ID를 가져옴
            user_id = idSave.getUserId();

            Log.d("Login", "Auto Login - user_id from SharedPreferences: " + user_id); // 로그 추가
        }else{
            user_id = idSave.getUserId();
            Log.d("Login", "user_id from IdSave: " + user_id); // 로그 추가
        }

        // url 작성
        ApiService UserInfoApiService = new ApiService();
        String Info_url = "http://203.250.133.156:8080/android/user_info" + "/" + user_id;
        UserInfoApiService.getUrl(Info_url);

        ApiService DeviceInfoApiService = new ApiService();
        String Device_Info_url = "http://203.250.133.156:8080/android/device_info" + "/" + user_id;
        DeviceInfoApiService.getUrl(Device_Info_url);

        User_Name = UserInfoApiService.getValue("user_name");
        Id = UserInfoApiService.getValue("user_id");
        Pw = UserInfoApiService.getValue("user_pw");
        Email = UserInfoApiService.getValue("user_email");
        Device_Name = DeviceInfoApiService.getValue("device_name");
        Device_Code = DeviceInfoApiService.getValue("device_code");
        Alarm_Status = UserInfoApiService.getValue("alarm_status");

        // 비밀번호 길이만큼 * 문자 저장
        String maskedPw;

        maskedPw = new String(new char[Pw.length()]).replace("\0", "*");
        Log.d("masked",maskedPw);

        User_Name_View.setText(User_Name);
        User_Id_View.setText(Id);
        User_Pw_View.setText(maskedPw);
        User_Email_View.setText(Email);
        User_Hard_Name_View.setText(Device_Name);
        User_Hard_Number_View.setText(Device_Code);

        if(Alarm_Status.equals("1")){
            // Alarm_Status가 "1"인 경우
            Alarm_On.setChecked(true);
            Alarm_Off.setChecked(false);
        }else if (Alarm_Status.equals("0")) {
            // Alarm_Status가 "0"인 경우
            Alarm_On.setChecked(false);
            Alarm_Off.setChecked(true);
        }
        // 알람 켜기 버튼 클릭 시
        Alarm_On.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 알람 켜기에 대한 동작 수행
                Alarm_On.setChecked(true);
                Alarm_Off.setChecked(false);

                ApiService AlarmStatusApiService = new ApiService();
                String Alarm_On_url = "http://203.250.133.156:8080/android/alarm_status/" + Id + "/" + Device_Code + "/" + "1";
                AlarmStatusApiService.postUrl(Alarm_On_url);
                // Toast 메시지 표시
                Toast.makeText(Setting.this, "알람이 켜졌습니다.", Toast.LENGTH_SHORT).show();
            }
        });

        // 알람 끄기 버튼 클릭 시
        Alarm_Off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 알람 끄기에 대한 동작 수행
                Alarm_On.setChecked(false);
                Alarm_Off.setChecked(true);

                ApiService AlarmStatusApiService = new ApiService();
                String Alarm_On_url = "http://203.250.133.156:8080/android/alarm_status/" + Id + "/" + Device_Code + "/" + "0";
                AlarmStatusApiService.postUrl(Alarm_On_url);
                // Toast 메시지 표시
                Toast.makeText(Setting.this, "알람이 꺼졌습니다.", Toast.LENGTH_SHORT).show();
            }
        });
        Pw_Change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Setting.this, PwChange.class);
                startActivity(intent);
            }
        });
        Delete_Hard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ApiService DeviceDeleteApiService = new ApiService();
                String Device_Delete_url = "http://203.250.133.156:8080/android/device_delete/" + Id + "/" + Device_Code;
                DeviceDeleteApiService.deleteUrl(Device_Delete_url);

                if(DeviceDeleteApiService.getStatus() == 200) {
                    Toast.makeText(Setting.this, "기기가 삭제됐습니다.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Setting.this, Regist.class);
                    startActivity(intent);

                }else{
                    Toast.makeText(Setting.this, "기기 삭제에 실패하였습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        Delete_User.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ApiService UserDeleteApiService = new ApiService();
                String User_Delete_url = "http://203.250.133.156:8080/android/user_delete/" + Id + "/" + Pw;
                UserDeleteApiService.deleteUrl(User_Delete_url);
                Log.d("url",User_Delete_url);

                if(UserDeleteApiService.getStatus() == 200) {
                    Toast.makeText(Setting.this, "계정이 삭제 됐습니다.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Setting.this, Login.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(Setting.this, "계정 삭제에 실패하였습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        LogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                idSave.clearData();
                // 로그인 화면으로 이동
                Intent intent = new Intent(Setting.this, Login.class);
                startActivity(intent);
            }
        });
    }
    @Override
    public void onBackPressed() {
        // 로그인 화면으로 이동
        startActivity(new Intent(Setting.this, MainActivity.class));
        // 현재 액티비티 종료
        finish();
    }
}