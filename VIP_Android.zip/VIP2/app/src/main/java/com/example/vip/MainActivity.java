package com.example.vip;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    private Handler handler;
    private Timer timer;
    ImageButton User_Info_Button;
    TextView main_device_name, humidity, temp, air_pollution, fine_dust;
    String Name, Code, Humidity, Temp, Air_Pollution, Fine_Dust;
    String user_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        handler = new Handler();
        timer = new Timer();

        User_Info_Button = findViewById(R.id.user_info_button);

        User_Info_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Setting.class);
                startActivity(intent);
            }
        });

        IdSave idSave = (IdSave) getApplication();
        int isAutoLogin = idSave.getIsAutoLogin();

        if(isAutoLogin == 1)
        {
            // 사용자의 ID를 가져옴
            user_id = idSave.getUserId();

            Log.d("Login", "Auto Login - user_id from SharedPreferences: " + user_id); // 로그 추가
        }else{
            user_id = idSave.getUserId();
            Log.d("Login", "user_id from IdSave: " + user_id); // 로그 추가
        }

        // url 작성
        ApiService MainApiService = new ApiService();
        String Name_url = "http://203.250.133.156:8080/android/device_info" + "/" + user_id;
        MainApiService.getUrl(Name_url);

        Name = MainApiService.getValue("device_name");
        Code = MainApiService.getValue("device_code");

        main_device_name = findViewById(R.id.main_device_name);

        main_device_name.setText(Name);

        // 3초마다 서버에서 값을 업데이트
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        // 서버에서 값을 받아와서 변수에 업데이트
                        updateValuesFromServer();
                    }
                });
            }
        }, 0, 3000); // 3초마다 실행
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 액티비티가 종료되면 타이머 중지
        timer.cancel();
    }
    private void updateValuesFromServer() {
        // url 작성
        ApiService sensor_ApiService = new ApiService();
        String Sensor_url = "http://203.250.133.156:8080/android/device_sensor/" + user_id + "/" + Code;
        sensor_ApiService.getUrl(Sensor_url);

        Humidity = sensor_ApiService.getValue("humidity");
        Temp = sensor_ApiService.getValue("temperature");
        Air_Pollution = sensor_ApiService.getValue("air_pollution");
        Fine_Dust = sensor_ApiService.getValue("usefine_dustr_pw");

        humidity = findViewById(R.id.humidity);
        temp = findViewById(R.id.temp);
        air_pollution = findViewById(R.id.air_pollution);
        fine_dust = findViewById(R.id.fine_dust);

        humidity.setText(Humidity);
        temp.setText(Temp);
        air_pollution.setText(Air_Pollution);
        fine_dust.setText(Fine_Dust);
    }
}